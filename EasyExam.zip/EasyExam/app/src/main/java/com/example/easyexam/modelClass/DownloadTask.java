package com.example.easyexam.modelClass;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.view.ContextThemeWrapper;
import androidx.core.content.FileProvider;

import com.example.easyexam.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class DownloadTask {
    private static final String TAG = "Download Task";
    /* access modifiers changed from: private */
    public Context context;
    /* access modifiers changed from: private */
    public String downloadFileName = "";
    /* access modifiers changed from: private */
    public String downloadUrl = "";
    /* access modifiers changed from: private */
    public ProgressDialog progressDialog;

    public DownloadTask(Context context2, String str) {
        this.context = context2;
        this.downloadUrl = str;
        String substring = str.substring(str.lastIndexOf(47), str.length());
        this.downloadFileName = substring;
        Log.e(TAG, substring);
        new DownloadingTask().execute(new Void[0]);
    }

    private class DownloadingTask extends AsyncTask<Void, Void, Void> {
        File apkStorage;
        File outputFile;
        StringBuilder stringBuilder;

        private DownloadingTask() {
            this.apkStorage = null;
            this.outputFile = null;
        }

        /* access modifiers changed from: protected */
        public void onPreExecute() {
            super.onPreExecute();
            ProgressDialog unused = DownloadTask.this.progressDialog = new ProgressDialog(DownloadTask.this.context);
            DownloadTask.this.progressDialog.setMessage("Downloading...");
            DownloadTask.this.progressDialog.setCancelable(false);
            DownloadTask.this.progressDialog.show();
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(Void voidR) {
            try {
                if (this.outputFile != null) {
                    DownloadTask.this.progressDialog.dismiss();
                    AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(DownloadTask.this.context, (int) R.style.AppTheme1));
                    builder.setTitle( "Document  ");
                    builder.setMessage("Document Downloaded Successfully  \n File path is : " + this.outputFile);
                    builder.setCancelable(false);
                    builder.setPositiveButton((CharSequence) "ok", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    });
                    builder.setNegativeButton((CharSequence) "Open file", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                        @SuppressLint("WrongConstant")
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                            File file = new File(DownloadingTask.this.outputFile.getPath());
                            Context access$200 = DownloadTask.this.context;
                            Uri uriForFile = FileProvider.getUriForFile(access$200, DownloadTask.this.context.getApplicationContext().getPackageName() + ".provider", file);
                            Intent intent = new Intent("android.intent.action.VIEW");
                            intent.setDataAndType(uriForFile, "application/pdf");
                            intent.addFlags(268435456);
                            intent.addFlags(67108864);
                            intent.setFlags(1);
                            intent.addFlags(64);
                            try {
                                DownloadTask.this.context.startActivity(intent);
                            } catch (ActivityNotFoundException unused) {
                                Toast.makeText(DownloadTask.this.context, "No Application available to view PDF", 0).show();
                            }
                        }
                    });
                    builder.show();
                    Toast.makeText(DownloadTask.this.context, "Document Downloaded Successfully", Toast.LENGTH_SHORT).show();
                } else {
                    new Handler().postDelayed(new Runnable() {
                        public void run() {
                        }
                    }, 3000);
                    Log.e(DownloadTask.TAG, "Download Failed");
                }
            } catch (Exception e) {
                e.printStackTrace();
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                    }
                }, 3000);
                Log.e(DownloadTask.TAG, "Download Failed with Exception - " + e.getLocalizedMessage());
            }
            super.onPostExecute(voidR);
        }

        /* access modifiers changed from: protected */
        public Void doInBackground(Void... voidArr) {
            try {
                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(DownloadTask.this.downloadUrl).openConnection();
                httpURLConnection.setRequestMethod("GET");
                httpURLConnection.connect();
                if (httpURLConnection.getResponseCode() != 200) {
                    Log.e(DownloadTask.TAG, "Server returned HTTP " + httpURLConnection.getResponseCode() + " " + httpURLConnection.getResponseMessage());
                }
                File externalStorageDirectory = Environment.getExternalStorageDirectory();
                if (!externalStorageDirectory.exists()) {
                    StringBuilder sb = new StringBuilder();
                    this.stringBuilder = sb;
                    sb.append(externalStorageDirectory.getAbsolutePath());
                    this.stringBuilder.append("/");
                    this.stringBuilder.append("Collegefile");
                    new File(this.stringBuilder.toString()).mkdirs();
                }
                if (new Comman.CheckForSDCard().isSDCardPresent()) {
                    this.apkStorage = new File(Environment.getExternalStorageDirectory().toString() + "/CollegeFile/");
                } else {
                    Toast.makeText(DownloadTask.this.context, "Oops!! There is no SD Card.", Toast.LENGTH_SHORT).show();
                }
                if (!this.apkStorage.exists()) {
                    new File(Environment.getExternalStorageDirectory().toString() + "/Collegefile/").mkdir();
                    Log.e(DownloadTask.TAG, "Directory Created.");
                }
                File file = new File(this.apkStorage, DownloadTask.this.downloadFileName);
                this.outputFile = file;
                if (file.exists()) {
                    this.outputFile.delete();
                }
                FileOutputStream fileOutputStream = new FileOutputStream(this.outputFile);
                InputStream inputStream = httpURLConnection.getInputStream();
                byte[] bArr = new byte[1024];
                while (true) {
                    int read = inputStream.read(bArr);
                    if (read == -1) {
                        break;
                    }
                    fileOutputStream.write(bArr, 0, read);
                }
                fileOutputStream.close();
                inputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
                this.outputFile = null;
                Log.e(DownloadTask.TAG, "Download Error Exception " + e.getMessage());
            }
            return null;
        }
    }
}
