package com.example.easyexam.Rest;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class NewExample {
    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("data")
    @Expose
    private NewData data;
    @SerializedName("message")
    @Expose
    private String message;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public NewData getData() {
        return data;
    }

    public void setData(NewData data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
