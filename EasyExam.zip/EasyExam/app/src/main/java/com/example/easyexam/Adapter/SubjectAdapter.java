package com.example.easyexam.Adapter;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.easyexam.Activity.NewsActivity;
import com.example.easyexam.Activity.StudyMaterialActivity;
import com.example.easyexam.Activity.SubjectActivity;
import com.example.easyexam.Activity.SubjectWiseExamActivity;
import com.example.easyexam.Activity.SubjectWiseResultsActivity;
import com.example.easyexam.R;
import com.example.easyexam.Rest.Datum;
import com.example.easyexam.modelClass.Comman;
import com.example.easyexam.modelClass.TouchImageView;

import java.util.List;

import static com.example.easyexam.modelClass.Comman.REDIRECT_PAGE;


public class SubjectAdapter extends RecyclerView.Adapter<SubjectAdapter.ViewHolder> {

    List<Datum> newslist;
    Context contet;
    public Dialog dialog;

    public SubjectAdapter(SubjectActivity newsActivity, List<Datum> items) {
        this.newslist = items;
        this.contet = newsActivity;
    }

    @Override
    public SubjectAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemview = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_medum_data, null);


        return new SubjectAdapter.ViewHolder(itemview);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onBindViewHolder(final SubjectAdapter.ViewHolder holder, final int position) {
        holder.std_name.setText(newslist.get(position).getSubjectName());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Comman.SUBJECT_ID = newslist.get(position).getSubjectId();
                Comman.SUBJECT_NAME = newslist.get(position).getSubjectName();
                if (REDIRECT_PAGE == 3) {
                    Intent intent = new Intent(contet, StudyMaterialActivity.class);
                    intent.putExtra("SUBJECT_IDS", newslist.get(position).getSubjectId());
                    intent.putExtra("SUBJECT_NAME", newslist.get(position).getSubjectName());
                    contet.startActivity(intent);
                } else {
                    Intent intent = new Intent(contet, SubjectWiseExamActivity.class);
                    intent.putExtra("SUBJECT_IDS", newslist.get(position).getSubjectId());
                    intent.putExtra("SUBJECT_NAME", newslist.get(position).getSubjectName());
                    contet.startActivity(intent);
                }


            }
        });

    }

    @Override
    public int getItemCount() {
        return newslist.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView std_name;


        public ViewHolder(View itemView) {
            super(itemView);
            std_name = (TextView) itemView.findViewById(R.id.std_name);

        }
    }
}
