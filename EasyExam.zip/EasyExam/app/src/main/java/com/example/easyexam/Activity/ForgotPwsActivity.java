package com.example.easyexam.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.easyexam.R;
import com.example.easyexam.Rest.ApiService;
import com.example.easyexam.Rest.Example;
import com.example.easyexam.Rest.RetroClient;
import com.example.easyexam.modelClass.AppValidation;
import com.example.easyexam.modelClass.Comman;
import com.example.easyexam.modelClass.SharedPreferenceManagerFile;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForgotPwsActivity extends AppCompatActivity {
    ApiService apiService;
    Button bt_login;
    TextInputEditText ed_PhoneNo;
    ProgressDialog pDialog;
    public SharedPreferenceManagerFile sharedPref;
    TextInputLayout txtPhoneNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_pws);
        this.apiService = (ApiService) RetroClient.getClient().create(ApiService.class);
        this.sharedPref = new SharedPreferenceManagerFile(this);
        initView();
        Comman.checkAndRequestPermissions(this);
    }

    private void initView() {
        this.ed_PhoneNo = (TextInputEditText) findViewById(R.id.ed_PhoneNo);
        this.txtPhoneNo = (TextInputLayout) findViewById(R.id.txtPhoneNo);
        bt_login = (Button) findViewById(R.id.bt_login);
        bt_login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (!Comman.isInternetAvailable(ForgotPwsActivity.this)) {
                    Toast.makeText(ForgotPwsActivity.this, "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!AppValidation.edvalidates(ed_PhoneNo.getText().toString().trim(), ed_PhoneNo, "Field is required.", txtPhoneNo)) {
                    return;
                }
                ApiCallTostudentLogin(ed_PhoneNo.getText().toString().trim());
            }
        });

    }

    private void ApiCallTostudentLogin(String trim) {
        ProgressDialog progressDialog = new ProgressDialog(this);
        this.pDialog = progressDialog;
        progressDialog.setIndeterminate(false);
        this.pDialog.setMessage("Please wait...");
        this.pDialog.setCancelable(false);
        this.pDialog.show();
        this.apiService.GetCallToForGotPws(trim).enqueue(new Callback<Example>() {
            public void onFailure(Call<Example> call, Throwable th) {
            }

            public void onResponse(Call<Example> call, Response<Example> response) {
                pDialog.dismiss();
                if (response.body().getStatus() == 1) {
                    Toast.makeText(ForgotPwsActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(ForgotPwsActivity.this, LoginActivity.class));
                    finish();
                    return;
                }
                Toast.makeText(ForgotPwsActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}