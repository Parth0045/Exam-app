package com.example.easyexam.Rest;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface ApiService {
    @FormUrlEncoded
    @POST("api/student_login")
    Call<NewExample> GetCallTostudentLogin(@Field("email") String str, @Field("password") String str2);

    @FormUrlEncoded
    @POST("api/student_forget_password")
    Call<Example> GetCallToForGotPws(@Field("email") String str);

    //    @FormUrlEncoded
    @Multipart
    @POST("api/student_register")
    Call<Example> GetCallTostudentRegister(@Part MultipartBody.Part file, @Part("enroll_no") RequestBody trim, @Part("fullname") RequestBody str, @Part("email") RequestBody str2, @Part("mobile_no") RequestBody str3, @Part("password") RequestBody str4, @Part("department_id") int i, @Part("semester_id") int i2);

    @FormUrlEncoded
    @POST("api/get_semesters")
    Call<Example> GetGetfacultyBySemester(@Field("department_id") int i);

    @FormUrlEncoded
    @POST("api/get_student_detail")
    Call<NewExample> GetStudentDetails(@Field("student_id") String i);

    @FormUrlEncoded
    @POST("api/get_study_material")
    Call<Example> GetStudyMaterial(@Field("department_id") String department_id, @Field("semester_id") String semester_id,@Field("subject_id") String subject_id);

    @FormUrlEncoded
    @POST("api/get_subjects")
    Call<Example> GetSubject(@Field("semester_id") String i);

    @FormUrlEncoded
    @POST("api/get_subject_wise_exam")
    Call<Example> GetSubjectWiseExam(@Field("subject_id") String subject_id,@Field("student_id") String student_id);

    @FormUrlEncoded
    @POST("api/get_exam_question_list")
    Call<Example> GetQuestionsList(@Field("exam_id") String i);

    @FormUrlEncoded
    @POST("api/get_student_exam_result")
    Call<Example> GetSubjectWiseResults(@Field("exam_id") String exam_id, @Field("student_id") String student_id);

    @FormUrlEncoded
    @POST("api/submit_student_exam")
    Call<Example> GetSubmitQuestionsList(@Field("exam_id") String exam_id, @Field("student_id") String student_id, @Field("correct_que") String correct_que);

    @GET("api/get_news_notice")
    Call<Example> GetNews();

    @GET("api/get_slider")
    Call<Example> GetSlider();

    @GET("api/get_departments")
    Call<Example> Getfaculty();
}
