package com.example.easyexam.modelClass;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreferenceManagerFile {
    public static String EMAIL = "Email";
    public static String FACULTY_ID = "DepartmentId";
    public static String FILE_NAME = "";
    public static String FULLNAME = "fullname";
    public static String ISLOGIN = "Login";
    public static String PHONE_NO = "mobile_number";
    public static String SEMESTERID = "semester_id";
    public static String STUDENT_ID = "student_id";
    public static String IMAGE_PARTH = "image_path";
    public static String IMAGE = "photo";
    SharedPreferences moSharedPreferences;

    public SharedPreferenceManagerFile(Context context) {
        try {
            this.moSharedPreferences = context.getApplicationContext().getSharedPreferences(FILE_NAME, Context.MODE_MULTI_PROCESS);
        } catch (Exception unused) {
            this.moSharedPreferences = context.getApplicationContext().getSharedPreferences(FILE_NAME, 0);
        }
    }

    public void setStringSharedPreference(String str, String str2) {
        SharedPreferences sharedPreferences = this.moSharedPreferences;
        if (sharedPreferences == null || str2 == null) {
            SharedPreferences.Editor edit = this.moSharedPreferences.edit();
            edit.putString(str, "");
            edit.commit();
            edit.apply();
            return;
        }
        SharedPreferences.Editor edit2 = sharedPreferences.edit();
        edit2.putString(str, str2);
        edit2.commit();
        edit2.apply();
    }

    public void setBooleanSharedPreference(String str, Boolean bool) {
        SharedPreferences sharedPreferences = this.moSharedPreferences;
        if (sharedPreferences == null || bool == null) {
            SharedPreferences.Editor edit = this.moSharedPreferences.edit();
            edit.putBoolean(str, false);
            edit.commit();
            edit.apply();
            return;
        }
        SharedPreferences.Editor edit2 = sharedPreferences.edit();
        edit2.putBoolean(str, bool.booleanValue());
        edit2.commit();
        edit2.apply();
    }

    public void setIntSharedPreference(String str, Integer num) {
        SharedPreferences sharedPreferences = this.moSharedPreferences;
        if (sharedPreferences == null || num == null) {
            SharedPreferences.Editor edit = this.moSharedPreferences.edit();
            edit.putInt(str, 0);
            edit.commit();
            edit.apply();
            return;
        }
        SharedPreferences.Editor edit2 = sharedPreferences.edit();
        edit2.putInt(str, num.intValue());
        edit2.commit();
        edit2.apply();
    }

    public Integer getIntSharedPreference(String str) {
        SharedPreferences sharedPreferences = this.moSharedPreferences;
        if (sharedPreferences != null) {
            return Integer.valueOf(sharedPreferences.getInt(str, 0));
        }
        return null;
    }

    public Boolean getBooleanSharedPreference(String str) {
        SharedPreferences sharedPreferences = this.moSharedPreferences;
        if (sharedPreferences != null) {
            return Boolean.valueOf(sharedPreferences.getBoolean(str, false));
        }
        return null;
    }

    public String getFromStringSharedPreference(String str) {
        SharedPreferences sharedPreferences = this.moSharedPreferences;
        if (sharedPreferences != null) {
            return sharedPreferences.getString(str, (String) null);
        }
        return null;
    }

    public Boolean clearPreference() {
        SharedPreferences sharedPreferences = this.moSharedPreferences;
        if (sharedPreferences != null) {
            SharedPreferences.Editor edit = sharedPreferences.edit();
            edit.putString(FACULTY_ID, "");
            edit.putString(EMAIL, "");
            edit.putString(SEMESTERID, "");
            edit.putString(PHONE_NO, "");
            edit.putString(FULLNAME, "");
            edit.putString(IMAGE_PARTH, "");
            edit.putString(IMAGE, "");
            edit.putBoolean(ISLOGIN, false);
            edit.commit();
            edit.apply();
        }
        return true;
    }
}
