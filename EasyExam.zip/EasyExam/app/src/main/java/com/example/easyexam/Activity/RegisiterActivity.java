package com.example.easyexam.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.easyexam.Rest.NewData;
import com.example.easyexam.Rest.NewExample;
import com.example.easyexam.modelClass.APIcall;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.example.easyexam.R;
import com.example.easyexam.Rest.ApiService;
import com.example.easyexam.Rest.Datum;
import com.example.easyexam.Rest.Example;
import com.example.easyexam.Rest.RetroClient;
import com.example.easyexam.modelClass.AppValidation;
import com.example.easyexam.modelClass.Comman;
import com.example.easyexam.modelClass.SharedPreferenceManagerFile;
import com.google.gson.Gson;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.easyexam.modelClass.SharedPreferenceManagerFile.IMAGE;
import static com.example.easyexam.modelClass.SharedPreferenceManagerFile.IMAGE_PARTH;

public class RegisiterActivity extends AppCompatActivity implements APIcall.ApiCallListner {
    int FacultyId = 0;
    int SemesterId = 0;
    ApiService apiService;
    Button bt_signup;
    Button bt_submit;
    TextInputEditText ed_User;
    TextInputEditText ed_confirm_password;
    TextInputEditText ed_email;
    TextInputEditText ed_Enroll_no;
    TextInputEditText ed_password;
    TextInputEditText ed_phone_no;
    TextInputEditText ed_semester;
    TextInputEditText ed_department_name;
    ProgressDialog pDialog;
    public SharedPreferenceManagerFile sharedPref;
    Spinner sp_faculty;
    Spinner sp_semester;
    TextView tvAlreadyAccount;
    TextView txt_profile_update;
    TextInputLayout txConPassword;
    TextInputLayout txt_semester;
    TextInputLayout txt_department_name;
    TextInputLayout txEnroll_no;
    TextInputLayout txEmail;
    TextInputLayout txPassword;
    TextInputLayout txPhone;
    TextInputLayout txUser;
    ImageView iv_user_profile;
    FrameLayout fl_update_profile;
    LinearLayout ll_faculty;
    LinearLayout ll_semester;

    public static final int SELECT_PICTURE = 101;
    String imageUploadpath = "";
    String imageUploadFileName = "";
    String STD_ID;
    private static final MediaType MEDIA_TYPE_PNG = MediaType.get("image/*");

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_registration);
        apiService = (ApiService) RetroClient.getClient().create(ApiService.class);
        this.sharedPref = new SharedPreferenceManagerFile(this);
        STD_ID = sharedPref.getFromStringSharedPreference(SharedPreferenceManagerFile.STUDENT_ID);
        initView();
    }

    private void initView() {
        this.txUser = (TextInputLayout) findViewById(R.id.txUser);
        this.iv_user_profile = (ImageView) findViewById(R.id.iv_user_profile);
        this.ed_User = (TextInputEditText) findViewById(R.id.ed_User);
        this.txEmail = (TextInputLayout) findViewById(R.id.txEmail);
        this.txt_department_name = (TextInputLayout) findViewById(R.id.txt_department_name);
        this.ed_email = (TextInputEditText) findViewById(R.id.ed_email);
        this.ed_Enroll_no = (TextInputEditText) findViewById(R.id.ed_Enroll_no);
        this.ed_department_name = (TextInputEditText) findViewById(R.id.ed_department_name);
        this.ed_semester = (TextInputEditText) findViewById(R.id.ed_semester);
        this.txPhone = (TextInputLayout) findViewById(R.id.txPhone);
        this.txt_semester = (TextInputLayout) findViewById(R.id.txt_semester);
        this.txEnroll_no = (TextInputLayout) findViewById(R.id.txEnroll_no);
        this.ed_phone_no = (TextInputEditText) findViewById(R.id.ed_phone_no);
        this.sp_faculty = (Spinner) findViewById(R.id.sp_faculty);
        this.sp_semester = (Spinner) findViewById(R.id.sp_semester);
        this.txPassword = (TextInputLayout) findViewById(R.id.txPassword);
        this.ed_password = (TextInputEditText) findViewById(R.id.ed_password);
        this.txConPassword = (TextInputLayout) findViewById(R.id.txConPassword);
        this.ed_confirm_password = (TextInputEditText) findViewById(R.id.ed_confirm_password);
        this.bt_signup = (Button) findViewById(R.id.bt_signup);
        this.bt_submit = (Button) findViewById(R.id.bt_submit);
        this.fl_update_profile = findViewById(R.id.fl_update_profile);
        this.txt_profile_update = findViewById(R.id.txt_profile_update);
        this.ll_faculty = findViewById(R.id.ll_faculty);
        this.ll_semester = findViewById(R.id.ll_semester);

        tvAlreadyAccount = (TextView) findViewById(R.id.tvAlreadyAccount);
        bt_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Comman.isInternetAvailable(RegisiterActivity.this)) {
                    Toast.makeText(RegisiterActivity.this, "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
                }

                if (!AppValidation.edvalidates(RegisiterActivity.this.ed_User.getText().toString().trim(), RegisiterActivity.this.ed_User, "Field is required.", RegisiterActivity.this.txUser)
                        | !AppValidation.validateEmail(RegisiterActivity.this.ed_email.getText().toString().trim(), RegisiterActivity.this.ed_email, "Field is required.", RegisiterActivity.this.txEmail)
                        | !AppValidation.edvalidates(RegisiterActivity.this.ed_Enroll_no.getText().toString().trim(), RegisiterActivity.this.ed_Enroll_no, "Field is required.", RegisiterActivity.this.txEnroll_no)
                        | !AppValidation.edvalidates(RegisiterActivity.this.ed_phone_no.getText().toString().trim(), RegisiterActivity.this.ed_phone_no, "Field is required.", RegisiterActivity.this.txPhone)
//                        | !AppValidation.edvalidates(RegisiterActivity.this.ed_password.getText().toString().trim(), RegisiterActivity.this.ed_password, "Field is required.", RegisiterActivity.this.txPassword)
                        | !AppValidation.edvalidates(RegisiterActivity.this.ed_confirm_password.getText().toString().trim(), RegisiterActivity.this.ed_confirm_password, "Field is required.", RegisiterActivity.this.txConPassword)
                ) {
                    return;
                }
                if (imageUploadFileName.equals("")) {
                    Toast.makeText(RegisiterActivity.this, "Please select image.", Toast.LENGTH_SHORT).show();
                    return;
                }
//                RegisiterActivity regisiterActivity = RegisiterActivity.this;
//                regisiterActivity.ApiCallTostudentRegister(ed_Enroll_no.getText().toString().trim(), regisiterActivity.ed_User.getText().toString().trim(), RegisiterActivity.this.ed_email.getText().toString().trim(), RegisiterActivity.this.ed_phone_no.getText().toString().trim(), RegisiterActivity.this.ed_confirm_password.getText().toString().trim());
                GetAPICallUpdateUser(ed_Enroll_no.getText().toString(), ed_User.getText().toString(), ed_email.getText().toString(), ed_phone_no.getText().toString(), ed_confirm_password.getText().toString());
            }
        });

        fl_update_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, SELECT_PICTURE);
            }
        });
        tvAlreadyAccount.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (Comman.isInternetAvailable(RegisiterActivity.this)) {
                    RegisiterActivity.this.startActivity(new Intent(RegisiterActivity.this, LoginActivity.class));
                    RegisiterActivity.this.finish();
                    return;
                }
                Toast.makeText(RegisiterActivity.this, "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
            }
        });
        ApiGetfaculty();
        this.bt_signup.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (!Comman.isInternetAvailable(RegisiterActivity.this)) {
                    Toast.makeText(RegisiterActivity.this, "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
                }

                if (!AppValidation.edvalidates(RegisiterActivity.this.ed_User.getText().toString().trim(), RegisiterActivity.this.ed_User, "Field is required.", RegisiterActivity.this.txUser)
                        | !AppValidation.validateEmail(RegisiterActivity.this.ed_email.getText().toString().trim(), RegisiterActivity.this.ed_email, "Field is required.", RegisiterActivity.this.txEmail)
                        | !AppValidation.edvalidates(RegisiterActivity.this.ed_Enroll_no.getText().toString().trim(), RegisiterActivity.this.ed_Enroll_no, "Field is required.", RegisiterActivity.this.txEnroll_no)
                        | !AppValidation.edvalidates(RegisiterActivity.this.ed_phone_no.getText().toString().trim(), RegisiterActivity.this.ed_phone_no, "Field is required.", RegisiterActivity.this.txPhone)
//                        | !AppValidation.edvalidates(RegisiterActivity.this.ed_password.getText().toString().trim(), RegisiterActivity.this.ed_password, "Field is required.", RegisiterActivity.this.txPassword)
                        | !AppValidation.edvalidates(RegisiterActivity.this.ed_confirm_password.getText().toString().trim(), RegisiterActivity.this.ed_confirm_password, "Field is required.", RegisiterActivity.this.txConPassword)
                ) {
                    return;
                }
                if (imageUploadFileName.equals("")) {
                    Toast.makeText(RegisiterActivity.this, "Please select image.", Toast.LENGTH_SHORT).show();
                    return;
                }
//                RegisiterActivity regisiterActivity = RegisiterActivity.this;
//                regisiterActivity.ApiCallTostudentRegister(ed_Enroll_no.getText().toString().trim(), regisiterActivity.ed_User.getText().toString().trim(), RegisiterActivity.this.ed_email.getText().toString().trim(), RegisiterActivity.this.ed_phone_no.getText().toString().trim(), RegisiterActivity.this.ed_confirm_password.getText().toString().trim());
                GetAPICallRegistrationUser(ed_Enroll_no.getText().toString(), ed_User.getText().toString(), ed_email.getText().toString(), ed_phone_no.getText().toString(), ed_confirm_password.getText().toString());
            }
        });
        if (Comman.REDIRECT_PROFILE_PAGE == 1) {
            txt_profile_update.setText("UPDATE PROFILE");
            ll_faculty.setVisibility(View.GONE);
            txt_department_name.setVisibility(View.VISIBLE);
            ll_semester.setVisibility(View.GONE);
            bt_submit.setVisibility(View.VISIBLE);
            bt_signup.setVisibility(View.GONE);
            txt_semester.setVisibility(View.GONE);
            tvAlreadyAccount.setVisibility(View.GONE);
            String STD_ID = sharedPref.getFromStringSharedPreference(SharedPreferenceManagerFile.STUDENT_ID);
            ApiGetStudentDetails(STD_ID);
        } else {
            txt_profile_update.setText("REGISTER");
            ll_faculty.setVisibility(View.VISIBLE);
            txt_department_name.setVisibility(View.GONE);
            tvAlreadyAccount.setVisibility(View.VISIBLE);
            ll_semester.setVisibility(View.VISIBLE);
            txt_semester.setVisibility(View.GONE);
            bt_submit.setVisibility(View.GONE);
            bt_signup.setVisibility(View.VISIBLE);
        }
    }

    public void ApiGetfaculty() {
        try {
            ProgressDialog progressDialog = new ProgressDialog(this);
            pDialog = progressDialog;
            progressDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.setMessage("Please wait...");
            pDialog.show();
            apiService.Getfaculty().enqueue(new Callback<Example>() {
                public void onResponse(Call<Example> call, Response<Example> response) {
                    pDialog.dismiss();
                    final List<Datum> data = response.body().getData();
                    if (response.body().getStatus() == 1) {
                        ArrayList arrayList = new ArrayList();
                        for (int i = 0; i < data.size(); i++) {
                            arrayList.add(data.get(i).getDepartmentName());
                        }
                        ArrayAdapter arrayAdapter = new ArrayAdapter(RegisiterActivity.this, android.R.layout.simple_spinner_item, arrayList);
                        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        RegisiterActivity.this.sp_faculty.setAdapter(arrayAdapter);
                        RegisiterActivity.this.sp_faculty.setSelection(0);
                        RegisiterActivity.this.sp_faculty.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            public void onNothingSelected(AdapterView<?> adapterView) {
                            }

                            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                                RegisiterActivity.this.FacultyId = Integer.valueOf(((Datum) data.get(i)).getDepartmentId()).intValue();
                                RegisiterActivity.this.ApiGetfacultyBySemester(RegisiterActivity.this.FacultyId);
                            }
                        });
                    }
                }

                public void onFailure(Call<Example> call, Throwable th) {
                    RegisiterActivity.this.pDialog.dismiss();
                    Toast.makeText(RegisiterActivity.this, "Try Again", Toast.LENGTH_SHORT).show();
                }
            });
        } catch (Exception unused) {
        }
    }

    /* access modifiers changed from: private */
    public void ApiGetfacultyBySemester(int i) {
        try {
            ProgressDialog progressDialog = new ProgressDialog(this);
            pDialog = progressDialog;
            progressDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.setMessage("Please wait...");
            pDialog.show();
            apiService.GetGetfacultyBySemester(i).enqueue(new Callback<Example>() {
                public void onResponse(Call<Example> call, Response<Example> response) {
                    pDialog.dismiss();
                    final List<Datum> data = response.body().getData();
                    if (response.body().getStatus() == 1) {
                        ArrayList arrayList = new ArrayList();
                        for (int i = 0; i < data.size(); i++) {
                            arrayList.add(data.get(i).getSemesterName());
                        }
                        ArrayAdapter arrayAdapter = new ArrayAdapter(RegisiterActivity.this, android.R.layout.simple_spinner_item, arrayList);
                        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        RegisiterActivity.this.sp_semester.setAdapter(arrayAdapter);
                        RegisiterActivity.this.sp_semester.setSelection(0);
                        RegisiterActivity.this.sp_semester.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            public void onNothingSelected(AdapterView<?> adapterView) {
                            }

                            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                                RegisiterActivity.this.SemesterId = Integer.valueOf(((Datum) data.get(i)).getSemesterId()).intValue();
                            }
                        });
                    }
                }

                public void onFailure(Call<Example> call, Throwable th) {
                    RegisiterActivity.this.pDialog.dismiss();
                    Toast.makeText(RegisiterActivity.this, "Try Again", Toast.LENGTH_SHORT).show();
                }
            });
        } catch (Exception unused) {
        }
    }

    public void ApiGetStudentDetails(String s) {
//            ProgressDialog progressDialog = new ProgressDialog(this);
//            pDialog = progressDialog;
//            progressDialog.setIndeterminate(false);
//            pDialog.setCancelable(false);
//            pDialog.setMessage("Please wait...");
//            pDialog.show();
        apiService.GetStudentDetails(s).enqueue(new Callback<NewExample>() {
            public void onResponse(Call<NewExample> call, Response<NewExample> response) {
//                    pDialog.dismiss();
                NewData data = response.body().getData();
                if (response.body().getStatus() == 1) {
                    ed_Enroll_no.setText(Comman.isStrempty(data.getEnrollNo()));
                    ed_User.setText(Comman.isStrempty(data.getFullname()));
                    ed_email.setText(Comman.isStrempty(data.getEmail()));
                    ed_semester.setText(Comman.isStrempty(data.getSemesterName()));
                    ed_department_name.setText(Comman.isStrempty(data.getDepartmentName()));
                    ed_phone_no.setText(Comman.isStrempty(data.getMobileNo()));
                    Glide.with(getApplicationContext()).load(sharedPref.getFromStringSharedPreference(IMAGE_PARTH) + data.getPhoto()).error(R.drawable.image_placeholder_default)
                            .into(iv_user_profile);
                }
            }

            public void onFailure(Call<NewExample> call, Throwable th) {
//                pDialog.dismiss();
                Toast.makeText(RegisiterActivity.this, "Try Again", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case SELECT_PICTURE:
                if (resultCode == RESULT_OK) {
                    try {
                        Uri selectedImageUri = data.getData();
                        imageUploadpath = getPath(selectedImageUri);
                        File N_file = Comman.getCompressed(RegisiterActivity.this, imageUploadpath);
                        imageUploadpath = N_file.getPath();
                        imageUploadFileName = new File(imageUploadpath).getName();
                        Glide.with(this).load(imageUploadpath).centerCrop().placeholder(R.drawable.image_placeholder_default).into(iv_user_profile);
                    } catch (Exception e) {
                        Log.d("SUMITPATEL", "EROOR" + e.toString());
                    }
                }
                break;
        }
    }

    String res = "";

    public String getPath(Uri uri) {
        String[] projection = {MediaStore.Images.Media.DATA};
        Cursor cursor = this.managedQuery(uri, projection, null, null, null);
        if (cursor.moveToFirst()) {
            res = cursor.getString(cursor.getColumnIndexOrThrow("_data"));
        }
        return res;
    }

    private void GetAPICallRegistrationUser(String Enroll_no, String User, String email, String phone_no, String toString1) {
        RequestBody body = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("enroll_no", Enroll_no)
                .addFormDataPart("fullname", User)
                .addFormDataPart("email", email)
                .addFormDataPart("mobile_no", phone_no)
                .addFormDataPart("password", toString1)
                .addFormDataPart("department_id", String.valueOf(FacultyId))
                .addFormDataPart("semester_id", String.valueOf(SemesterId))
                .addFormDataPart("photo", imageUploadFileName,
                        RequestBody.create(new File(imageUploadpath), MEDIA_TYPE_PNG))
                .build();
        String url = "http://easyexam.skyzonesolution.com/api/student_register";
        APIcall apIcall = new APIcall(getApplicationContext());
        apIcall.isPost(true);
        apIcall.setBody(body);
        apIcall.execute(url, APIcall.OPERATION_REGISTET, this);

    }
    private void GetAPICallUpdateUser(String Enroll_no, String User, String email, String phone_no, String toString1) {
        RequestBody body = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
//                .addFormDataPart("enroll_no", Enroll_no)
                .addFormDataPart("student_id", STD_ID)
                .addFormDataPart("fullname", User)
                .addFormDataPart("email", email)
                .addFormDataPart("mobile_no", phone_no)
                .addFormDataPart("password", toString1)
                .addFormDataPart("photo", imageUploadFileName,
                        RequestBody.create(new File(imageUploadpath), MEDIA_TYPE_PNG))
                .build();
        String url = "http://easyexam.skyzonesolution.com/api/student_update_profile";
        APIcall apIcall = new APIcall(getApplicationContext());
        apIcall.isPost(true);
        apIcall.setBody(body);
        apIcall.execute(url, APIcall.OPERATION_UPDATE, this);

    }

    @Override
    public void onStartLoading(int operationCode) {
        ProgressDialog progressDialog = new ProgressDialog(this);
        this.pDialog = progressDialog;
        progressDialog.setIndeterminate(false);
        this.pDialog.setMessage("Please wait...");
        this.pDialog.setCancelable(false);
        this.pDialog.show();
    }

    @Override
    public void onProgress(int operationCode, int progress) {

    }

    @Override
    public void onSuccess(int operationCode, String response, Object customData) {
        this.pDialog.hide();
        if (APIcall.OPERATION_REGISTET == operationCode) {
            Gson gson = new Gson();
            Example exampleUser = gson.fromJson(response, Example.class);
            if (exampleUser.getStatus().intValue() == 1) {
                startActivity(new Intent(RegisiterActivity.this, LoginActivity.class));
                finish();
//                    RegisiterActivity.this.ApiCallTostudentLogin(str2, str4);
                Toast.makeText(RegisiterActivity.this, exampleUser.getMessage(), Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(RegisiterActivity.this, exampleUser.getMessage(), Toast.LENGTH_SHORT).show();
        }
        if (APIcall.OPERATION_UPDATE == operationCode) {
            Gson gson = new Gson();
            Example exampleUser = gson.fromJson(response, Example.class);
            if (exampleUser.getStatus().intValue() == 1) {
                startActivity(new Intent(RegisiterActivity.this, MainActivity.class));
                finish();
//                    RegisiterActivity.this.ApiCallTostudentLogin(str2, str4);
                Toast.makeText(RegisiterActivity.this, exampleUser.getMessage(), Toast.LENGTH_SHORT).show();
                return;
            }
        }
    }

    @Override
    public void onFail(int operationCode, String response) {

    }
}
