package com.example.easyexam.Activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.easyexam.Adapter.StudyMaterialAdapter;
import com.example.easyexam.R;
import com.example.easyexam.Rest.ApiService;
import com.example.easyexam.Rest.Datum;
import com.example.easyexam.Rest.Example;
import com.example.easyexam.Rest.RetroClient;
import com.example.easyexam.modelClass.SharedPreferenceManagerFile;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import retrofit2.Call;
import retrofit2.Callback;

import static android.provider.Settings.System.DATE_FORMAT;

public class StartExamActivity extends AppCompatActivity {

    TextView txt_question;
    TextView txt_time;
    RadioButton rb_ans_1;
    RadioButton rb_ans_2;
    RadioButton rb_ans_3;
    RadioButton rb_ans_4;
    ProgressDialog pDialog;
    ApiService apiService;
    RelativeLayout rl_main;
    ImageView iv_notfound;
    AppCompatButton bt_next;
    AppCompatButton bt_previous;
    List<Datum> items;
    int TotalItems = 0;
    private RadioGroup radioGroup;
    private RadioButton radioButton;
    public SharedPreferenceManagerFile sharedPref;
    String STD_ID = "";
    String EXAM_ID = "";
    int Total_correct_marks = 0;
    String correct_ans = "";
    private String NEW_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    String EXAM_START = "";
    String EXAM_END = "";
    Date EXAMSTART_date;
    Date EXAMEND_date;
    CountDownTimer countDownTimer;
    public static String timeLeftFormatted;
    Datum mdatum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_exam);

        sharedPref = new SharedPreferenceManagerFile(this);
        STD_ID = sharedPref.getFromStringSharedPreference(SharedPreferenceManagerFile.STUDENT_ID);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Exam start " + getIntent().getStringExtra("EXAM_NAME"));
        EXAM_ID = getIntent().getStringExtra("EXAM_ID");
        EXAM_START = getIntent().getStringExtra("EXAM_START");
        EXAM_END = getIntent().getStringExtra("EXAM_END");
        apiService = RetroClient.getClient().create(ApiService.class);

        txt_question = findViewById(R.id.txt_question);
        bt_previous = findViewById(R.id.bt_previous);
        txt_time = findViewById(R.id.txt_time);
        rb_ans_1 = findViewById(R.id.rb_ans_1);
        rb_ans_2 = findViewById(R.id.rb_ans_2);
        rb_ans_3 = findViewById(R.id.rb_ans_3);
        rb_ans_4 = findViewById(R.id.rb_ans_4);
        bt_next = findViewById(R.id.bt_next);
        rl_main = findViewById(R.id.rl_main);
        radioGroup = findViewById(R.id.radioGroup);
        iv_notfound = findViewById(R.id.iv_notfound);

        Calendar c = Calendar.getInstance();
        @SuppressLint("SimpleDateFormat") SimpleDateFormat dateFormat = new SimpleDateFormat(NEW_DATE_FORMAT);
        Date EXAMSTART = new Date();
        try {
            EXAMSTART = dateFormat.parse(EXAM_START);
            c.setTime(EXAMSTART);
            EXAMSTART_date = new Date();
            EXAMSTART_date = c.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        Date EXAMEND = new Date();
        try {
            EXAMEND = dateFormat.parse(EXAM_END);
            c.setTime(EXAMEND);
            EXAMEND_date = new Date();
            EXAMEND_date = c.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        GetCountDownStart(EXAMSTART_date, EXAMEND_date);
        GetQuestionsList(EXAM_ID);
        bt_previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TotalItems--;
                if (TotalItems == 0) {
                    TotalItems = 0;
                    bt_previous.setClickable(false);
                } else {
                    bt_previous.setClickable(true);
                }
                lordOldData(TotalItems);
            }
        });
        bt_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bt_previous.setClickable(true);
                TotalItems++;
                int selectedId = radioGroup.getCheckedRadioButtonId();
                radioButton = (RadioButton) findViewById(selectedId);
                if (correct_ans.equals(radioButton.getText())) {
                    Total_correct_marks++;
                }
                mdatum.setQty_ans(radioButton.getText().toString());
                if (TotalItems < items.size()) {
                    lordData(TotalItems);
                } else {
                    new AlertDialog.Builder(StartExamActivity.this)
                            .setTitle("Submit Exam complete")
                            .setMessage("Good luck on your Exam?")
                            .setCancelable(false)
                            // Specifying a listener allows you to take an action before dismissing the dialog.
                            // The dialog is automatically dismissed when a dialog button is clicked.
                            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    GetSubmitQuestionsList(Total_correct_marks, EXAM_ID, STD_ID);
                                    dialog.dismiss();
                                    // Continue with delete operation
                                }
                            })
                            .show();
                }
            }
        });

    }

    private void lordOldData(int totalItems) {
        radioGroup.clearCheck();
        mdatum = items.get(totalItems);
        correct_ans = mdatum.getCorrectAnswer();
        txt_question.setText("Que : " + (totalItems - 1) + " " + mdatum.getTitle());
        rb_ans_1.setText(mdatum.getOption1());
        rb_ans_2.setText(mdatum.getOption2());
        rb_ans_3.setText(mdatum.getOption3());
        rb_ans_4.setText(mdatum.getOption4());
        if (rb_ans_1.getText().toString().equals(items.get(totalItems).getQty_ans())) {
            rb_ans_1.setChecked(true);
        }
        if (rb_ans_2.getText().toString().equals(items.get(totalItems).getQty_ans())) {
            rb_ans_2.setChecked(true);
        }
        if (rb_ans_3.getText().toString().equals(items.get(totalItems).getQty_ans())) {
            rb_ans_3.setChecked(true);
        }
        if (rb_ans_4.getText().toString().equals(items.get(totalItems).getQty_ans())) {
            rb_ans_4.setChecked(true);
        }


    }

    private void GetSubmitQuestionsList(int total_correct_marks, String EXAM_ID, String STD_ID) {
        pDialog = new ProgressDialog(StartExamActivity.this);
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
        Call<Example> call = apiService.GetSubmitQuestionsList(EXAM_ID, STD_ID, String.valueOf(total_correct_marks));
        call.enqueue(new Callback<Example>() {
            @Override
            public void onResponse(Call<Example> call, retrofit2.Response<Example> response) {
                pDialog.dismiss();
                if (response.body().getStatus() == 1) {
                    Toast.makeText(StartExamActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(StartExamActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }
                onBackPressed();
                finish();
            }

            @Override
            public void onFailure(Call<Example> call, Throwable t) {
                Log.e(">>>>>>", t.toString());
                pDialog.dismiss();
                Toast.makeText(StartExamActivity.this, "Try Again", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void GetQuestionsList(String exam_id) {
        pDialog = new ProgressDialog(StartExamActivity.this);
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
        Call<Example> call = apiService.GetQuestionsList(exam_id);
        call.enqueue(new Callback<Example>() {
            @Override
            public void onResponse(Call<Example> call, retrofit2.Response<Example> response) {
                pDialog.dismiss();
                items = response.body().getData();
                if (response.body().getData().size() == 0) {
                    rl_main.setVisibility(View.GONE);
                    iv_notfound.setVisibility(View.VISIBLE);
                } else {
                    rl_main.setVisibility(View.VISIBLE);
                    iv_notfound.setVisibility(View.GONE);
                    lordData(0);
                }
            }

            @Override
            public void onFailure(Call<Example> call, Throwable t) {
                Log.e(">>>>>>", t.toString());
                rl_main.setVisibility(View.GONE);
                iv_notfound.setVisibility(View.VISIBLE);
                pDialog.dismiss();
                Toast.makeText(StartExamActivity.this, "Try Again", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void lordData(int pos) {
        mdatum = items.get(pos);
        correct_ans = mdatum.getCorrectAnswer();
        txt_question.setText("Que : " + (pos + 1) + " " + mdatum.getTitle());
        rb_ans_1.setText(mdatum.getOption1());
        rb_ans_2.setText(mdatum.getOption2());
        rb_ans_3.setText(mdatum.getOption3());
        rb_ans_4.setText(mdatum.getOption4());
        radioGroup.clearCheck();
//        radioGroup.clearChildFocus(rb_ans_1);
//        radioGroup.clearChildFocus(rb_ans_2);
//        radioGroup.clearChildFocus(rb_ans_3);
//        radioGroup.clearChildFocus(rb_ans_4);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {

            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(menuItem);
        }
    }

    private void GetCountDownStart(Date EXAMSTART_date, Date EXAMEND_date) {

        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        long diff = EXAMEND_date.getTime() - EXAMSTART_date.getTime();
        try {
            countDownTimer = new CountDownTimer(diff, 500) {
                @Override
                public void onTick(long l) {
                    long Days = l / (24 * 60 * 60 * 1000);
                    long Hours = l / (60 * 60 * 1000) % 24;
                    long Minutes = l / (60 * 1000) % 60;
                    long Seconds = l / 1000 % 60;
                    timeLeftFormatted = String.format(Locale.getDefault(), "%02d:%02d:%02d", Hours, Minutes, Seconds);
                    txt_time.setText(timeLeftFormatted);
                    Log.d(">>>>>>", ">>>>>>>>" + timeLeftFormatted);
                }

                @Override
                public void onFinish() {
                    new AlertDialog.Builder(StartExamActivity.this)
                            .setTitle("Time out")
                            .setMessage("Good luck on your Exam?")
                            .setCancelable(false)
                            // Specifying a listener allows you to take an action before dismissing the dialog.
                            // The dialog is automatically dismissed when a dialog button is clicked.
                            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    GetSubmitQuestionsList(Total_correct_marks, EXAM_ID, STD_ID);
                                    dialog.dismiss();
                                    // Continue with delete operation
                                }
                            })
                            .show();
                    countDownTimer.cancel();
                }
            }.start();
        } catch (Exception e) {
            countDownTimer.cancel();
            e.printStackTrace();
        }

    }
}