package com.example.easyexam.Adapter;

import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.easyexam.Activity.NewsActivity;
import com.example.easyexam.Activity.StudyMaterialActivity;
import com.example.easyexam.R;
import com.example.easyexam.Rest.Datum;
import com.example.easyexam.modelClass.DownloadTask;
import com.example.easyexam.modelClass.TouchImageView;

import java.util.List;

/**
 * Created by Rahul Patel on 1/30/2018.
 */

public class StudyMaterialAdapter extends RecyclerView.Adapter<StudyMaterialAdapter.ViewHolder> {

    List<Datum> newslist;
    Context contet;
    public Dialog dialog;

    public StudyMaterialAdapter(StudyMaterialActivity newsActivity, List<Datum> items) {
        this.newslist =  items;
       this.contet = newsActivity;
    }

    @Override
    public StudyMaterialAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemview = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_download_data, null);
        return new StudyMaterialAdapter.ViewHolder(itemview);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onBindViewHolder(final StudyMaterialAdapter.ViewHolder holder, final int position) {

        holder.download_name.setText(this.newslist.get(position).getTitle());
        holder.download_btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                new DownloadTask(contet, newslist.get(position).getImagePath() + newslist.get(position).getImgPdf());
            }
        });

    }

    @Override
    public int getItemCount() {
        return newslist.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        CardView download_btn;
        TextView download_name;

        public ViewHolder(View view) {
            super(view);
            this.download_name = (TextView) view.findViewById(R.id.download_name);
            this.download_btn = (CardView) view.findViewById(R.id.download_btn);
        }
    }
}
