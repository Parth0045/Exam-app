package com.example.easyexam.Activity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.easyexam.Adapter.SubjectAdapter;
import com.example.easyexam.Adapter.newsadapter;
import com.example.easyexam.R;
import com.example.easyexam.Rest.ApiService;
import com.example.easyexam.Rest.Datum;
import com.example.easyexam.Rest.Example;
import com.example.easyexam.Rest.RetroClient;
import com.example.easyexam.modelClass.SharedPreferenceManagerFile;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;

import static com.example.easyexam.modelClass.SharedPreferenceManagerFile.SEMESTERID;


public class SubjectActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ProgressDialog pDialog;
    ApiService apiService;
    ImageView ivnotfound;
    SharedPreferenceManagerFile sharedPreferenceManagerFile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Subject");
        ivnotfound = (ImageView) findViewById(R.id.iv_notfound);
        recyclerView = (RecyclerView) findViewById(R.id.news_recycle);
        sharedPreferenceManagerFile = new SharedPreferenceManagerFile(this);
        apiService = RetroClient.getClient().create(ApiService.class);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        GetSubject();
    }

    public void GetSubject() {
        pDialog = new ProgressDialog(SubjectActivity.this);
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
        Call<Example> call = apiService.GetSubject(sharedPreferenceManagerFile.getFromStringSharedPreference(SEMESTERID));
        call.enqueue(new Callback<Example>() {
            @Override
            public void onResponse(Call<Example> call, retrofit2.Response<Example> response) {
                pDialog.dismiss();
                List<Datum> items = response.body().getData();
                if (response.body().getData().size() == 0) {
                    recyclerView.setVisibility(View.GONE);
                    ivnotfound.setVisibility(View.VISIBLE);
                } else {
                    recyclerView.setAdapter(new SubjectAdapter(SubjectActivity.this, items));
                }

            }

            @Override
            public void onFailure(Call<Example> call, Throwable t) {
                Log.e(">>>>>>", t.toString());
                pDialog.dismiss();
                Toast.makeText(SubjectActivity.this, "Try Again", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {

            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(menuItem);
        }
    }
}
