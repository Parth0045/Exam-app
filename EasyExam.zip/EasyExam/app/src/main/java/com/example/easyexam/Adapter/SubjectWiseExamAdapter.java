package com.example.easyexam.Adapter;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.easyexam.Activity.StartExamActivity;
import com.example.easyexam.Activity.SubjectActivity;
import com.example.easyexam.Activity.SubjectWiseExamActivity;
import com.example.easyexam.Activity.SubjectWiseResultsActivity;
import com.example.easyexam.R;
import com.example.easyexam.Rest.Datum;
import com.example.easyexam.modelClass.Comman;
import com.example.easyexam.modelClass.TouchImageView;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import static com.example.easyexam.modelClass.Comman.REDIRECT_PAGE;


public class SubjectWiseExamAdapter extends RecyclerView.Adapter<SubjectWiseExamAdapter.ViewHolder> {

    List<Datum> newslist;
    Context contet;
    public Dialog dialog;
    Date c_cancle_date;
    Date current_dateas;

    public SubjectWiseExamAdapter(SubjectWiseExamActivity newsActivity, List<Datum> items) {
        this.newslist = items;
        this.contet = newsActivity;
    }

    @Override
    public SubjectWiseExamAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemview = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_subject_wise_exam, null);


        return new SubjectWiseExamAdapter.ViewHolder(itemview);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onBindViewHolder(final SubjectWiseExamAdapter.ViewHolder holder, final int position) {
//        holder.txt_exam_date.setText("Date : " + newslist.get(position).getExamDate());
        holder.txt_exam_name.setText("Exam name : " + Comman.isStrempty(newslist.get(position).getExamName()));
        holder.txt_total_marks.setText("Marks : " + Comman.isStrempty(newslist.get(position).getTotalMarks()));
//        holder.txt_status.setText("Status : " + newslist.get(position).getStatus());
        holder.txt_exam_note.setText("Note : " + Comman.isStrempty(newslist.get(position).getExamNote()));
        holder.txt_start_time.setText("Exam time : " + Comman.isStrempty(newslist.get(position).getExamStartDatetime()) + " to " + Comman.isStrempty(newslist.get(position).getExamEndDatetime()));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(REDIRECT_PAGE == 1){
//                    Intent intent = new Intent(contet, StartExamActivity.class);
//                    intent.putExtra("EXAM_ID", newslist.get(position).getExamId());
//                    intent.putExtra("EXAM_NAME", newslist.get(position).getExamName());
//                    intent.putExtra("EXAM_START", newslist.get(position).getExamStartDatetime());
//                    intent.putExtra("EXAM_END", newslist.get(position).getExamEndDatetime());
//                    contet.startActivity(intent);
                    if(!newslist.get(position).getValid()) {
                        DateFormat timeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        timeFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
                        Calendar cal = Calendar.getInstance();
                        Date date_cancels = null;
                        try {
                            date_cancels = timeFormat.parse(newslist.get(position).getExamStartDatetime());
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        cal.setTime(date_cancels);
                        cal.add(Calendar.MINUTE, 10);
                        timeFormat.format(cal.getTime());
                        c_cancle_date = cal.getTime();
                        current_dateas = new Date();
                        if (!current_dateas.after(c_cancle_date)) {
                            Intent intent = new Intent(contet, StartExamActivity.class);
                            intent.putExtra("EXAM_ID", newslist.get(position).getExamId());
                            intent.putExtra("EXAM_NAME", newslist.get(position).getExamName());
                            intent.putExtra("EXAM_START", newslist.get(position).getExamStartDatetime());
                            intent.putExtra("EXAM_END", newslist.get(position).getExamEndDatetime());
                            contet.startActivity(intent);
                        } else {
                            Toast.makeText(contet, "Time out for exam.", Toast.LENGTH_SHORT).show();

                        }

                    }else {
                        Toast.makeText(contet, "Exam already attempted.", Toast.LENGTH_SHORT).show();
                    }
                }else {
                    Intent intent = new Intent(contet, SubjectWiseResultsActivity.class);
                    intent.putExtra("EXAM_ID", newslist.get(position).getExamId());
                    contet.startActivity(intent);
                }

            }
        });

    }

    @Override
    public int getItemCount() {
        return newslist.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

//        TextView txt_exam_date;
        TextView txt_start_time;
        TextView txt_exam_name;
        TextView txt_total_marks;
        TextView txt_status;
        TextView txt_exam_note;


        public ViewHolder(View itemView) {
            super(itemView);
//            txt_exam_date = (TextView) itemView.findViewById(R.id.txt_exam_date);
            txt_exam_name = (TextView) itemView.findViewById(R.id.txt_exam_name);
            txt_start_time = (TextView) itemView.findViewById(R.id.txt_start_time);
            txt_total_marks = (TextView) itemView.findViewById(R.id.txt_total_marks);
            txt_exam_note = (TextView) itemView.findViewById(R.id.txt_exam_note);
            txt_status = (TextView) itemView.findViewById(R.id.txt_status);

        }
    }
//    public static long parseTime(String str) throws NumberFormatException {
//        if (str == null)
//            throw new NumberFormatException("parseTimeString null str");
//        if (str.isEmpty())
//            throw new NumberFormatException("parseTimeString empty str");
//
//        int h = 0;
//        int m, s;
//        String units[] = str.split(":");
//        assert (units.length == 2 || units.length == 3);
//        switch (units.length) {
//            case 2:
//                // mm:ss
//                m = Integer.parseInt(units[0]);
//                s = Integer.parseInt(units[1]);
//                break;
//
//            case 3:
//                // hh:mm:ss
//                h = Integer.parseInt(units[0]);
//                m = Integer.parseInt(units[1]);
//                s = Integer.parseInt(units[2]);
//                break;
//
//            default:
//                throw new NumberFormatException("parseTimeString failed:" + str);
//        }
//        if (m < 0 || m > 60 || s < 0 || s > 60 || h < 0)
//            throw new NumberFormatException("parseTimeString range error:" + str);
//        return h * 3600 + m * 60 + s;
//    }
//
//    private void GetCountDownStart(final MyViewHolder mholder) {
//
//        if (mholder.countDownTimer != null) {
//            mholder.countDownTimer.cancel();
//        }
//        Date current_dateas = new Date();
//        if (!current_dateas.after(event_date)) {
//            long diff = event_date.getTime() - current_dateas.getTime();
//
//            mholder.countDownTimer = new CountDownTimer(diff, 500) {
//
//                @Override
//                public void onTick(long l) {
//                    long Days = l / (24 * 60 * 60 * 1000);
//                    long Hours = l / (60 * 60 * 1000) % 24;
//                    long Minutes = l / (60 * 1000) % 60;
//                    long Seconds = l / 1000 % 60;
//                    //
//                    timeLeftFormatted = String.format(Locale.getDefault(), "%02d:%02d:%02d", Hours, Minutes, Seconds);
//                    char ch1 = timeLeftFormatted.charAt(0);
//                    char ch2 = timeLeftFormatted.charAt(1);
//
//                    char ch3 = timeLeftFormatted.charAt(3);
//                    char ch4 = timeLeftFormatted.charAt(4);
//
//                    char ch5 = timeLeftFormatted.charAt(6);
//                    char ch6 = timeLeftFormatted.charAt(7);
//
//                    if (mholder.binding.txtHfirst.getText().hashCode() != ch1) {
//                        mholder.binding.txtHfirst.setText(Character.toString(ch1));
//                    }
//                    if (mholder.binding.txtHfsecond.getText().hashCode() != ch2) {
//                        mholder.binding.txtHfsecond.setText(Character.toString(ch2));
//                    }
//                    if (mholder.binding.txtMfirst.getText().hashCode() != ch3) {
//                        mholder.binding.txtMfirst.setText(Character.toString(ch3));
//                    }
//                    if (mholder.binding.txtMSecond.getText().hashCode() != ch4) {
//                        mholder.binding.txtMSecond.setText(Character.toString(ch4));
//                    }
//                    if (mholder.binding.txtSFirst.getText().hashCode() != ch5) {
//                        mholder.binding.txtSFirst.setText(Character.toString(ch5));
//                    }
//                    if (mholder.binding.txtSSecond.getText().hashCode() != ch6) {
//                        mholder.binding.txtSSecond.setText(Character.toString(ch6));
//                    }
//                }
//
//                @Override
//                public void onFinish() {
//                    mholder.countDownTimer.cancel();
//                }
//            }.start();
//        }
//        /*runnable = new Runnable() {
//            @Override
//            public void run() {
//                try {
//
//                    handler.postDelayed(this, 500);
//                    Date current_dateas = new Date();
//                    if (!current_dateas.after(event_date)) {
//                        long diff = event_date.getTime() - current_dateas.getTime();
//                        long Days = diff / (24 * 60 * 60 * 1000);
//                        long Hours = diff / (60 * 60 * 1000) % 24;
//                        long Minutes = diff / (60 * 1000) % 60;
//                        long Seconds = diff / 1000 % 60;
//                        //
//                        timeLeftFormatted = String.format(Locale.getDefault(), "%02d:%02d:%02d", Hours, Minutes, Seconds);
//
//                        char ch1 = timeLeftFormatted.charAt(0);
//                        char ch2 = timeLeftFormatted.charAt(1);
//
//                        char ch3 = timeLeftFormatted.charAt(3);
//                        char ch4 = timeLeftFormatted.charAt(4);
//
//                        char ch5 = timeLeftFormatted.charAt(6);
//                        char ch6 = timeLeftFormatted.charAt(7);
//
//                        if (mholder.binding.txtHfirst.getText().hashCode() != ch1) {
//                            mholder.binding.txtHfirst.setText(Character.toString(ch1));
//                        }
//                        if (mholder.binding.txtHfsecond.getText().hashCode() != ch2) {
//                            mholder.binding.txtHfsecond.setText(Character.toString(ch2));
//                        }
//                        if (mholder.binding.txtMfirst.getText().hashCode() != ch3) {
//                            mholder.binding.txtMfirst.setText(Character.toString(ch3));
//                        }
//                        if (mholder.binding.txtMSecond.getText().hashCode() != ch4) {
//                            mholder.binding.txtMSecond.setText(Character.toString(ch4));
//                        }
//                        if (mholder.binding.txtSFirst.getText().hashCode() != ch5) {
//                            mholder.binding.txtSFirst.setText(Character.toString(ch5));
//                        }
//                        if (mholder.binding.txtSSecond.getText().hashCode() != ch6) {
//                            mholder.binding.txtSSecond.setText(Character.toString(ch6));
//                        }
//                    } else {
//
//                        handler.removeCallbacks(runnable);
//                    }
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        };
//        handler.postDelayed(runnable, 0);
//    }*/
//    }
}
