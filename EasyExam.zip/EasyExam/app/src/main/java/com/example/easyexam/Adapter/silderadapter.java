package com.example.easyexam.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.fragment.app.FragmentActivity;
import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;
import com.example.easyexam.R;
import com.example.easyexam.Rest.Datum;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Rahul Patel on 2/17/2018.
 */

public class silderadapter extends PagerAdapter {
    Integer[] silderlist;
    Context contet;
    LayoutInflater mLayoutInflater;


    public silderadapter(FragmentActivity mainFragment,  Integer[] items) {
        this.silderlist = items;
        this.contet = mainFragment;
        mLayoutInflater = (LayoutInflater) contet.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return silderlist.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == ((RelativeLayout) object);

    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        View itemView = mLayoutInflater.inflate(R.layout.pager1, container, false);

        final ImageView imageView = (ImageView) itemView.findViewById(R.id.category_imageee);
        Glide.with(contet).load(silderlist[position]).into(imageView);

        container.addView(itemView);


        return itemView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((RelativeLayout) object);
    }

}
