package com.example.easyexam.Activity;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.bumptech.glide.Glide;
import com.example.easyexam.R;
import com.example.easyexam.Rest.ApiService;
import com.example.easyexam.Rest.RetroClient;
import com.example.easyexam.modelClass.Comman;
import com.example.easyexam.modelClass.SharedPreferenceManagerFile;
import com.google.android.material.navigation.NavigationView;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.example.easyexam.modelClass.Comman.REDIRECT_PAGE;
import static com.example.easyexam.modelClass.SharedPreferenceManagerFile.FULLNAME;
import static com.example.easyexam.modelClass.SharedPreferenceManagerFile.IMAGE;
import static com.example.easyexam.modelClass.SharedPreferenceManagerFile.IMAGE_PARTH;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getSimpleName();
    String MY_PREFS_NAME = "school";
    ApiService apiService;
    Boolean doubleBackToExitPressedOnce = false;
    SharedPreferences.Editor editor;
    LinearLayout ll_logout;
    DrawerLayout mDrawerLayout;
    FragmentManager mFragmentManager;
    FragmentTransaction mFragmentTransaction;
    NavigationView mNavigationView;
    Toolbar mytoolbar;
    SharedPreferenceManagerFile sharedPref;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mytoolbar = (Toolbar) findViewById(R.id.toolbar);
        sharedPref = new SharedPreferenceManagerFile(this);
        editor = getSharedPreferences(MY_PREFS_NAME, 0).edit();
        apiService = (ApiService) RetroClient.getClient().create(ApiService.class);
        mytoolbar.setTitle((int) R.string.app_name);
        Comman.checkAndRequestPermissions(this);
        setSupportActionBar(mytoolbar);
        this.mDrawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        this.mNavigationView = (NavigationView) findViewById(R.id.navigationview);
        FragmentManager supportFragmentManager = getSupportFragmentManager();
        this.mFragmentManager = supportFragmentManager;
        FragmentTransaction beginTransaction = supportFragmentManager.beginTransaction();
        this.mFragmentTransaction = beginTransaction;
        beginTransaction.replace(R.id.containerView, new MainFragment()).commit();
        this.mNavigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        MainActivity.this.mDrawerLayout.closeDrawers();
                    }
                }, 200);
                if (menuItem.getItemId() == R.id.nav_share) {
                    if (Comman.isInternetAvailable(MainActivity.this)) {
                        Intent intent = new Intent();
                        intent.setAction("android.intent.action.SEND");
                        intent.putExtra("android.intent.extra.TEXT", getString(R.string.app_name) + "\n" + "I want to share this with you Here you can download this app from PlayStore" + "\nhttps://play.google.com/store/apps/details?id=" + MainActivity.this.getPackageName());
                        intent.setType("text/plain");
                        MainActivity.this.startActivity(intent);
                    } else {
                        Toast.makeText(MainActivity.this, "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
                    }
                } if (menuItem.getItemId() == R.id.nav_logout) {
                    if (Comman.isInternetAvailable(MainActivity.this)) {
                        sharedPref.clearPreference();
                        Intent intent= new Intent(MainActivity.this,LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(MainActivity.this, "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
                    }
                }
                if (menuItem.getItemId() == R.id.nav_rate) {
                    if (Comman.isInternetAvailable(MainActivity.this)) {
                        MainActivity mainActivity = MainActivity.this;
                        mainActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + MainActivity.this.getPackageName())));
                    } else {
                        Toast.makeText(MainActivity.this, "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
                    }
                }
                if (menuItem.getItemId() == R.id.nav_exam_list) {
                    if (Comman.isInternetAvailable(MainActivity.this)) {
                        REDIRECT_PAGE = 1;
                        Intent intent = new Intent(MainActivity.this, SubjectActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(MainActivity.this, "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
                    }
                }
                if (menuItem.getItemId() == R.id.nav_exam_results) {
                    if (Comman.isInternetAvailable(MainActivity.this)) {
                        REDIRECT_PAGE = 2;
                        MainActivity.this.startActivity(new Intent(MainActivity.this, SubjectActivity.class));
                    } else {
                        Toast.makeText(MainActivity.this, "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
                    }
                }
                if (menuItem.getItemId() == R.id.nav_syllabus) {
                    if (Comman.isInternetAvailable(MainActivity.this)) {
                        REDIRECT_PAGE = 3;
                        MainActivity.this.startActivity(new Intent(MainActivity.this, SubjectActivity.class));
                    } else {
                        Toast.makeText(MainActivity.this, "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
                    }
                }
                if (menuItem.getItemId() == R.id.nav_News) {
                    if (Comman.isInternetAvailable(MainActivity.this)) {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, NewsActivity.class));
                    } else {
                        Toast.makeText(MainActivity.this, "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
                    }
                }
//                if (menuItem.getItemId() == R.id.nav_notic) {
//                    if (Comman.isInternetAvailable(MainActivity.this)) {
//                        MainActivity.this.startActivity(new Intent(MainActivity.this, NoticeActivity.class));
//                    } else {
//                        Toast.makeText(MainActivity.this, "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
//                    }
//                }
                return false;
            }
        });
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, this.mDrawerLayout, this.mytoolbar, R.string.app_name, R.string.app_name);
        this.mDrawerLayout.setDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        View view= mNavigationView.inflateHeaderView(R.layout.nav_header_main);
        CircleImageView imageView = view.findViewById(R.id.profile_image);
        ImageView iv_edit = view.findViewById(R.id.iv_edit);
        Glide.with(this).load(sharedPref.getFromStringSharedPreference(IMAGE_PARTH) + sharedPref.getFromStringSharedPreference(IMAGE)).error(R.drawable.image_placeholder_default)
                .into(imageView);
        TextView txt_name = view.findViewById(R.id.txt_name);
        txt_name.setText(sharedPref.getFromStringSharedPreference(FULLNAME));
        iv_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Comman.REDIRECT_PROFILE_PAGE = 1 ;
                startActivity(new Intent(MainActivity.this, RegisiterActivity.class));
            }
        });
    }

    public void onBackPressed() {
        if (this.doubleBackToExitPressedOnce.booleanValue()) {
            super.onBackPressed();
            System.exit(0);
            return;
        }
        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();
    }
}