package com.example.easyexam.Adapter;

import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.easyexam.Activity.NewsActivity;
import com.example.easyexam.R;
import com.example.easyexam.Rest.Datum;
import com.example.easyexam.modelClass.Comman;
import com.example.easyexam.modelClass.DownloadTask;
import com.example.easyexam.modelClass.TouchImageView;

import java.util.List;

/**
 * Created by Rahul Patel on 1/30/2018.
 */

public class newsadapter extends RecyclerView.Adapter<newsadapter.ViewHolder> {

    List<Datum> newslist;
    Context contet;
    public Dialog dialog;

    public newsadapter(NewsActivity newsActivity, List<Datum> items) {
        this.newslist = items;
        this.contet = newsActivity;
    }

    @Override
    public newsadapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemview = LayoutInflater.from(parent.getContext()).inflate(R.layout.news_single_data, null);


        return new newsadapter.ViewHolder(itemview);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onBindViewHolder(final newsadapter.ViewHolder holder, final int position) {

        Datum dis = newslist.get(position);
        holder.title.setText(Comman.isStrempty(newslist.get(position).getTitle()));
        holder.dis.setText(Html.fromHtml(dis.getDescription()).toString());
        if(isPresent(newslist.get(position).getImage())){
            Glide.with(contet).load(contet.getResources().getDrawable(R.drawable.ic_pdf))
                    .into(holder.imageView);
        }else {
            Glide.with(contet).load(newslist.get(position).getImagePath() + newslist.get(position).getImage())
                    .into(holder.imageView);
        }

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isPresent(newslist.get(position).getImage())) {
                    new DownloadTask(contet, newslist.get(position).getImagePath() + newslist.get(position).getImage());

                } else {
                    dialog = new Dialog(contet);
                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    dialog.setCancelable(true);
                    dialog.setContentView(R.layout.show_fullscreen_image);
                    TouchImageView imageView = (TouchImageView) dialog.findViewById(R.id.IMAGEID);

                    Glide.with(contet)
                            .load(newslist.get(position).getImagePath() + newslist.get(position).getImage())
                            .into(imageView);

                    dialog.show();
                }

            }
        });

    }

    public boolean isPresent(String sentence) {
        if (sentence.indexOf(".pdf") >= 0)
            return true;
        else
            return false;
    }

    @Override
    public int getItemCount() {
        return newslist.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView title, date, dis;
        ImageView imageView;
        CardView cardView;

        public ViewHolder(View itemView) {
            super(itemView);

            title = (TextView) itemView.findViewById(R.id.news_title);
            imageView = (ImageView) itemView.findViewById(R.id.imageView);
            dis = (TextView) itemView.findViewById(R.id.news_dis);
            cardView = (CardView) itemView.findViewById(R.id.cardview);

        }
    }
}
