package com.example.easyexam.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.easyexam.Rest.NewData;
import com.example.easyexam.Rest.NewExample;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.example.easyexam.R;
import com.example.easyexam.Rest.ApiService;
import com.example.easyexam.Rest.RetroClient;
import com.example.easyexam.modelClass.AppValidation;
import com.example.easyexam.modelClass.Comman;
import com.example.easyexam.modelClass.SharedPreferenceManagerFile;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    ApiService apiService;
    Button bt_login;
    TextInputEditText ed_PhoneNo;
    TextInputEditText ed_password;
    LinearLayout lyt_sign_up_for_account;
    ProgressDialog pDialog;
    /* access modifiers changed from: private */
    public SharedPreferenceManagerFile sharedPref;
    TextInputLayout txtPhoneNo;
    TextInputLayout txt_password;
    TextView tvforgot;


    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_login);
        this.apiService = (ApiService) RetroClient.getClient().create(ApiService.class);
        this.sharedPref = new SharedPreferenceManagerFile(this);
        initView();
        Comman.checkAndRequestPermissions(this);
    }

    private void initView() {
        this.tvforgot = (TextView) findViewById(R.id.tvforgot);
        tvforgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Comman.isInternetAvailable(LoginActivity.this)) {
                    LoginActivity.this.startActivity(new Intent(LoginActivity.this, ForgotPwsActivity.class));
                    return;
                }
                Toast.makeText(LoginActivity.this, "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
            }
        });
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.lyt_sign_up_for_account);
        this.lyt_sign_up_for_account = linearLayout;
        linearLayout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (Comman.isInternetAvailable(LoginActivity.this)) {
                    LoginActivity.this.startActivity(new Intent(LoginActivity.this, RegisiterActivity.class));
                    LoginActivity.this.finish();
                    return;
                }
                Toast.makeText(LoginActivity.this, "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
            }
        });
        this.txtPhoneNo = (TextInputLayout) findViewById(R.id.txtPhoneNo);
        this.txt_password = (TextInputLayout) findViewById(R.id.txt_password);
        this.ed_PhoneNo = (TextInputEditText) findViewById(R.id.ed_PhoneNo);
        this.ed_password = (TextInputEditText) findViewById(R.id.ed_password);

        Button button = (Button) findViewById(R.id.bt_login);
        this.bt_login = button;
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (!Comman.isInternetAvailable(LoginActivity.this)) {
                    Toast.makeText(LoginActivity.this, "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!AppValidation.edvalidates(LoginActivity.this.ed_PhoneNo.getText().toString().trim(), LoginActivity.this.ed_PhoneNo, "Field is required.", LoginActivity.this.txtPhoneNo) ||
                        !AppValidation.edvalidates(LoginActivity.this.ed_password.getText().toString().trim(), LoginActivity.this.ed_password, "Field is required.", LoginActivity.this.txt_password)) {
                    return;
                }
                LoginActivity loginActivity = LoginActivity.this;
                loginActivity.ApiCallTostudentLogin(loginActivity.ed_PhoneNo.getText().toString().trim(), LoginActivity.this.ed_password.getText().toString().trim());
            }
        });
    }

    public void ApiCallTostudentLogin(String str, String str2) {
        ProgressDialog progressDialog = new ProgressDialog(this);
        this.pDialog = progressDialog;
        progressDialog.setIndeterminate(false);
        this.pDialog.setMessage("Please wait...");
        this.pDialog.setCancelable(false);
        this.pDialog.show();
        this.apiService.GetCallTostudentLogin(str, str2).enqueue(new Callback<NewExample>() {


            public void onFailure(Call<NewExample> call, Throwable th) {
                pDialog.dismiss();
                Log.d("MAINURI", ">>>>>>>" + th.getMessage());
            }


            public void onResponse(Call<NewExample> call, Response<NewExample> response) {
                pDialog.dismiss();
                if (response.body().getStatus() == 1) {
                    NewData studentData = response.body().getData();
                    sharedPref.setBooleanSharedPreference(SharedPreferenceManagerFile.ISLOGIN, true);
                    sharedPref.setStringSharedPreference(SharedPreferenceManagerFile.FACULTY_ID, studentData.getDepartmentId());
                    sharedPref.setStringSharedPreference(SharedPreferenceManagerFile.STUDENT_ID, studentData.getStudentId());
                    sharedPref.setStringSharedPreference(SharedPreferenceManagerFile.SEMESTERID, studentData.getSemesterId());
                    sharedPref.setStringSharedPreference(SharedPreferenceManagerFile.EMAIL, studentData.getEmail());
                    sharedPref.setStringSharedPreference(SharedPreferenceManagerFile.FULLNAME, studentData.getFullname());
                    sharedPref.setStringSharedPreference(SharedPreferenceManagerFile.IMAGE_PARTH, studentData.getImagePath());
                    sharedPref.setStringSharedPreference(SharedPreferenceManagerFile.IMAGE, studentData.getPhoto());
                    startActivity(new Intent(LoginActivity.this, MainActivity.class));
                    LoginActivity.this.finish();
                    Toast.makeText(LoginActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    return;
                }
                LoginActivity.this.sharedPref.setBooleanSharedPreference(SharedPreferenceManagerFile.ISLOGIN, false);
                Toast.makeText(LoginActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
