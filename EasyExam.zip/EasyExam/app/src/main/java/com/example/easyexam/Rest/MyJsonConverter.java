package com.example.easyexam.Rest;

import com.bumptech.glide.load.Key;
import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.nio.charset.Charset;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import okio.Buffer;
import retrofit2.Converter;
import retrofit2.Retrofit;

public class MyJsonConverter extends Converter.Factory {
    private final Gson gson;

    public static MyJsonConverter create() {
        return create(new Gson());
    }

    public static MyJsonConverter create(Gson gson2) {
        return new MyJsonConverter(gson2);
    }

    private MyJsonConverter(Gson gson2) {
        if (gson2 != null) {
            this.gson = gson2;
            return;
        }
        throw new NullPointerException("gson == null");
    }

    public Converter<ResponseBody, ?> responseBodyConverter(Type type, Annotation[] annotationArr, Retrofit retrofit) {
        return new GsonResponseBodyConverter(this.gson, this.gson.getAdapter(TypeToken.get(type)));
    }

    public Converter<?, RequestBody> requestBodyConverter(Type type, Annotation[] annotationArr, Annotation[] annotationArr2, Retrofit retrofit) {
        return new GsonRequestBodyConverter(this.gson, this.gson.getAdapter(TypeToken.get(type)));
    }

    final class GsonRequestBodyConverter<T> implements Converter<T, RequestBody> {
        private final MediaType MEDIA_TYPE = MediaType.parse("application/json; charset=UTF-8");
        private final Charset UTF_8 = Charset.forName(Key.STRING_CHARSET_NAME);
        private final TypeAdapter<T> adapter;
        private final Gson gson;

        GsonRequestBodyConverter(Gson gson2, TypeAdapter<T> typeAdapter) {
            this.gson = gson2;
            this.adapter = typeAdapter;
        }

        public RequestBody convert(T t) throws IOException {
            Buffer buffer = new Buffer();
            JsonWriter newJsonWriter = this.gson.newJsonWriter(new OutputStreamWriter(buffer.outputStream(), this.UTF_8));
            this.adapter.write(newJsonWriter, t);
            newJsonWriter.close();
            return RequestBody.create(this.MEDIA_TYPE, buffer.readByteString());
        }
    }

    final class GsonResponseBodyConverter<T> implements Converter<ResponseBody, T> {
        private final TypeAdapter<T> adapter;
        private final Gson gson;

        GsonResponseBodyConverter(Gson gson2, TypeAdapter<T> typeAdapter) {
            this.gson = gson2;
            this.adapter = typeAdapter;
        }

        public T convert(ResponseBody responseBody) throws IOException {
            try {
                return this.adapter.fromJson(responseBody.string().replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n<string xmlns=\"http://tempuri.org/\">", "").replace("</string>", ""));
            } finally {
                responseBody.close();
            }
        }
    }
}
