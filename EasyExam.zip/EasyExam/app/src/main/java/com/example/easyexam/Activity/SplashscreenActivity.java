package com.example.easyexam.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.example.easyexam.R;
import com.example.easyexam.modelClass.SharedPreferenceManagerFile;

public class SplashscreenActivity extends AppCompatActivity {

    ImageView image;
    Boolean islogin = false;
    SharedPreferenceManagerFile sharedPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashscreen);
        SharedPreferenceManagerFile sharedPreferenceManagerFile = new SharedPreferenceManagerFile(this);
        this.sharedPref = sharedPreferenceManagerFile;
        this.islogin = sharedPreferenceManagerFile.getBooleanSharedPreference(SharedPreferenceManagerFile.ISLOGIN);
        Logocopyanimation();
        new Handler().postDelayed(new Runnable() {
            public void run() {
                if (islogin.booleanValue()) {
                    startActivity(new Intent(SplashscreenActivity.this, MainActivity.class));
                    finish();
                    return;
                }
                startActivity(new Intent(SplashscreenActivity.this, LoginActivity.class));
                finish();
            }
        }, 2000);
    }

    private void Logocopyanimation() {
        AnimationUtils.loadAnimation(this, R.anim.anim);
        Animation loadAnimation = AnimationUtils.loadAnimation(this, R.anim.zoom_in);
        loadAnimation.reset();
        ImageView imageView = (ImageView) findViewById(R.id.image);
        this.image = imageView;
        try {
            imageView.clearAnimation();
            this.image.startAnimation(loadAnimation);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}