package com.example.easyexam.modelClass;


import android.content.Context;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.Log;

import com.example.easyexam.Rest.RetroClient;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;

public class APIcall {

    public static int OPERATION_REGISTET = 100001;
    public static int OPERATION_UPDATE = 100002;




    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    private ApiCallListner apiCallListner;
    Context moContext;
    private FormBody.Builder postBuilder;

    public APIcall(Context context) {
        moContext = context;
    }

    SharedPreferenceManagerFile sharedPreferenceManagerFile;
    private boolean isPost;

    private RequestBody body;

    public void setBody(RequestBody body) {
        this.body = body;
    }

    public void isPost(boolean isPost) {
        this.isPost = isPost;
    }

    public void setPostBuilder(FormBody.Builder postBuilder) {
        this.postBuilder = postBuilder;
    }

    private String tempSessionGUID;

    public void setTempSessionId(String tempSessionGUID) {
        this.tempSessionGUID = tempSessionGUID;
    }

    public interface ApiCallListner {
        public void onStartLoading(int operationCode);

        public void onProgress(int operationCode, int progress);

        public void onSuccess(int operationCode, String response, Object customData);

        public void onFail(int operationCode, String response);
    }

    private Object customData;

    public void setCustomData(Object customData) {
        this.customData = customData;
    }

    private int operationCode;
    private String url;
    private CallApiExecute callApiExecute;

    public void execute(String url, int operationCode, ApiCallListner apiCallListner) {
        this.operationCode = operationCode;
        this.url = url;
        this.url = this.url.replaceAll(" ", "%20");
        this.apiCallListner = apiCallListner;
        this.apiCallListner.onStartLoading(operationCode);
        callApiExecute = new CallApiExecute();
        callApiExecute.execute();
    }

    private class CallApiExecute extends AsyncTask<String, String, String> {

        String errorMsg = "Offers not found";

        @Override
        protected void onPreExecute() {
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                if (!url.contains("http")) {
                    url = RetroClient.BASE_URL + url;
                }
                sharedPreferenceManagerFile = new SharedPreferenceManagerFile(moContext);
                String userAgent = System.getProperty("http.agent");
                Log.i("userAgent", "userAgent:::" + userAgent);
                HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
                interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
                OkHttpClient.Builder okHttpBuilder = new OkHttpClient.Builder();
                okHttpBuilder.connectTimeout(60000, TimeUnit.MILLISECONDS);
                okHttpBuilder.readTimeout(60000, TimeUnit.MILLISECONDS);
                OkHttpClient client = okHttpBuilder.build();
               // okHttpBuilder.addInterceptor(interceptor);
                FormBody formBody = null;
                Request request;
                if (isPost && postBuilder != null) {
                    Log.i("CallApiExecute", "API Url:" + url);
                }

                Request.Builder reqBuilder = new Request.Builder();
                if (formBody != null) {
                    request = reqBuilder.url(url).post(formBody).build();
                } else if (body != null) {
                    request = reqBuilder.url(url).post(body).build();
                } else {
                    request = reqBuilder.url(url).build();
                }
                Response response = null;
                String responseStr = null;
                try {
                    response = client.newCall(request).execute();
                    responseStr = response.body().string();
                    Log.i("CallApiExecute", "CallApiExecute Response got:" + responseStr);
                    return responseStr;
                } catch (IOException e) {
                    Log.i("CallApiExecute", "Exception Message:" + e.getMessage());
                    e.printStackTrace();
                }
                return null;
            } catch (Exception e) {
                Log.i("SUMIT_CallApiExecute", "Exception Message:" + e.getMessage());
                return null;
            }

        }

        @Override
        protected void onPostExecute(String result) {
            if (!TextUtils.isEmpty(result)) {
                apiCallListner.onSuccess(operationCode, result, customData);
            } else {
                apiCallListner.onFail(operationCode, null);
            }
        }

        @Override
        protected void onProgressUpdate(String... progress) {
            if (apiCallListner != null) {
                apiCallListner.onProgress(operationCode, Integer.parseInt(progress[0]));
            }
            super.onProgressUpdate(progress);
        }
    }
}
