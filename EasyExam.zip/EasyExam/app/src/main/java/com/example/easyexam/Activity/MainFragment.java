package com.example.easyexam.Activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.ViewPager;

import com.example.easyexam.Adapter.silderadapter;
import com.example.easyexam.R;
import com.example.easyexam.Rest.ApiService;
import com.example.easyexam.Rest.Datum;
import com.example.easyexam.Rest.Example;
import com.example.easyexam.Rest.RetroClient;
import com.example.easyexam.modelClass.Comman;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.easyexam.modelClass.Comman.REDIRECT_PAGE;

public class MainFragment extends Fragment {
    Context context;
    List<Datum> items;
    FragmentManager mFragmentManager;
    Handler mHandler = new Handler();
    int min;
    ViewPager viewPager;
    ApiService apiService;

    LinearLayout ll_exam_list;
    LinearLayout ll_exam_results;
    LinearLayout ll_share_app;
    LinearLayout ll_rate_app;
    LinearLayout ll_News;
//    LinearLayout ll_Notice;
    LinearLayout ll_Syllabus;

    List<Integer> stringList = new ArrayList<>();

    Integer[] new_sss = new  Integer[]{
            R.drawable.banner,
            R.drawable.logo
    };

    ImageView staff;
    ImageView video;
    private String NEW_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    String EXAM_START = "";
    String EXAM_END = "";
    Date EXAMSTART_date;
    Date EXAMEND_date;
    CountDownTimer  countDownTimer;
    public static String timeLeftFormatted;


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.content_main, viewGroup, false);
        setHasOptionsMenu(true);
        this.apiService = (ApiService) RetroClient.getClient().create(ApiService.class);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle((int) R.string.app_name);
        viewPager = (ViewPager) inflate.findViewById(R.id.news_slider);
        min = viewPager.getCurrentItem();
        viewPager.setAdapter(new silderadapter(getActivity(), new_sss));
        final Handler handler = new Handler();
        final Runnable Update = new Runnable() {
            public void run() {
                if (min == new_sss.length) {
                    min = 0;
                }
                viewPager.setCurrentItem(min++, true);
            }
        };
        Timer swipeTimer = new Timer();
        swipeTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(Update);
            }
        }, 3000, 3000);
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                //  Collections.shuffle(os_versions);
                try {
                    if (min < items.size()) {
                        min++;
                        viewPager.setCurrentItem(min, true);
                    } else {
                        min = 0;
                        viewPager.setCurrentItem(min, true);
                    }
                    mHandler.postDelayed(this, 2000);
                } catch (Exception ex) {
                }

            }
        };
        ///slider();
        Calendar c = Calendar.getInstance();
        @SuppressLint("SimpleDateFormat") SimpleDateFormat dateFormat = new SimpleDateFormat(NEW_DATE_FORMAT);
        Date EXAMSTART = new Date();
        try {
            EXAMSTART = dateFormat.parse("2021-04-01 10:00:00");
            c.setTime(EXAMSTART);
            c.add(Calendar.MINUTE, 5);
            EXAMSTART_date = new Date();
            EXAMSTART_date = c.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        Date EXAMEND = new Date();
        try {
            EXAMEND = dateFormat.parse("2021-04-01 12:15:00");
            c.setTime(EXAMEND);
            EXAMEND_date = new Date();
            EXAMEND_date = c.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        GetCountDownStart(EXAMEND_date,EXAMSTART_date);

        this.mFragmentManager = getActivity().getSupportFragmentManager();
        ll_exam_list = inflate.findViewById(R.id.ll_exam_list);
        ll_exam_results = inflate.findViewById(R.id.ll_exam_results);
        ll_share_app = inflate.findViewById(R.id.ll_share_app);
        ll_rate_app = inflate.findViewById(R.id.ll_rate_app);
        ll_News = inflate.findViewById(R.id.ll_News);
//        ll_Notice = inflate.findViewById(R.id.ll_Notice);
        ll_Syllabus = inflate.findViewById(R.id.ll_Syllabus);


        this.ll_exam_list.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (Comman.isInternetAvailable(MainFragment.this.getContext())) {
                    REDIRECT_PAGE = 1;
                    Intent intent = new Intent(getActivity(), SubjectActivity.class);
                    getActivity().startActivity(intent);
                    return;
                }
                Toast.makeText(MainFragment.this.getContext(), "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
            }
        });
        this.ll_exam_results.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (Comman.isInternetAvailable(MainFragment.this.getContext())) {
                    REDIRECT_PAGE = 2;
                    startActivity(new Intent(getActivity(), SubjectActivity.class));
//                    Intent intent = new Intent(MainFragment.this.getActivity(), StanderActivity.class);
//                    intent.putExtra("POS", 1);
//                    MainFragment.this.startActivity(intent);
                    return;
                }
                Toast.makeText(MainFragment.this.getContext(), "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
            }
        });
        this.ll_share_app.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (Comman.isInternetAvailable(MainFragment.this.getContext())) {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.TEXT", getString(R.string.app_name) + "\n" + "I want to share this with you Here you can download this app from PlayStore" + "\nhttps://play.google.com/store/apps/details?id=" +  getActivity().getPackageName());
                    intent.setType("text/plain");
                   getActivity().startActivity(intent);
                    return;
                }
                Toast.makeText(MainFragment.this.getContext(), "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
            }
        });
        this.ll_rate_app.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (Comman.isInternetAvailable(MainFragment.this.getContext())) {
                    if (Comman.isInternetAvailable(getContext())) {
                        getActivity().startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + getActivity().getPackageName())));
                    } else {
                        Toast.makeText(getActivity(), "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
                    }
                    return;
                }
                Toast.makeText(MainFragment.this.getContext(), "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
            }
        });
        this.ll_News.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (Comman.isInternetAvailable(MainFragment.this.getContext())) {
                   getActivity().startActivity(new Intent(getActivity(), NewsActivity.class));
                    return;
                }
                Toast.makeText(MainFragment.this.getContext(), "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
            }
        });
//        this.ll_Notice.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View view) {
//                if (Comman.isInternetAvailable(MainFragment.this.getContext())) {
//                    getActivity().startActivity(new Intent(getActivity(), NoticeActivity.class));
//                    return;
//                }
//                Toast.makeText(MainFragment.this.getContext(), "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
//            }
//        });
        this.ll_Syllabus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (Comman.isInternetAvailable(MainFragment.this.getContext())) {
                    REDIRECT_PAGE = 3;
                    getActivity().startActivity(new Intent(getActivity(), SubjectActivity.class));
                    return;
                }

                Toast.makeText(MainFragment.this.getContext(), "No connection found. Please connect & try again.", Toast.LENGTH_SHORT).show();
            }
        });
        return inflate;
    }


    private void GetCountDownStart(Date EXAMSTART_date, Date EXAMEND_date) {

        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        long diff = EXAMSTART_date.getTime() - EXAMEND_date.getTime();
        countDownTimer = new CountDownTimer(diff, 500) {
            @Override
            public void onTick(long l) {
                long Days = l / (24 * 60 * 60 * 1000);
                long Hours = l / (60 * 60 * 1000) % 24;
                long Minutes = l / (60 * 1000) % 60;
                long Seconds = l / 1000 % 60;
                timeLeftFormatted = String.format(Locale.getDefault(), "%02d:%02d:%02d", Hours, Minutes, Seconds);
                Log.d(">>>>>>",">>>>>>>>" + timeLeftFormatted);
            }

            @Override
            public void onFinish() {
                countDownTimer.cancel();
            }
        }.start();
    }
}
