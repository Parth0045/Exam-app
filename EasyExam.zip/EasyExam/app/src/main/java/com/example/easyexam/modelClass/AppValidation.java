package com.example.easyexam.modelClass;

import android.text.TextUtils;
import android.util.Patterns;
import android.widget.EditText;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class AppValidation {
    public static boolean edvalidate(String str, EditText editText, String str2) {
        if (str.isEmpty()) {
            editText.setError(str2);
            editText.requestFocus();
            return false;
        }
        editText.setError((CharSequence) null);
        return true;
    }

    public static boolean edvalidates(String str, TextInputEditText textInputEditText, String str2, TextInputLayout textInputLayout) {
        if (str.isEmpty()) {
            textInputLayout.setErrorEnabled(true);
            textInputLayout.setError(str2);
            return false;
        }
        textInputLayout.setError((CharSequence) null);
        return true;
    }

    public static final boolean isValidEmail(CharSequence charSequence) {
        return !TextUtils.isEmpty(charSequence) && Patterns.EMAIL_ADDRESS.matcher(charSequence).matches();
    }

    public static boolean validateEmail(String str, TextInputEditText textInputEditText, String str2, TextInputLayout textInputLayout) {
        if (str.isEmpty()) {
            textInputLayout.setErrorEnabled(true);
            textInputLayout.setError(str2);
            return false;
        } else if (!isValidEmail(str.trim())) {
            textInputLayout.setErrorEnabled(true);
            textInputLayout.setError("Please enter a valid email address");
            return false;
        } else {
            textInputLayout.setError((CharSequence) null);
            return true;
        }
    }

    public static boolean edvalidateMatchingPassword(String str, EditText editText, String str2, TextInputLayout textInputLayout) {
        if (str.isEmpty() && str2.length() >= 6 && str2.length() <= 20) {
            textInputLayout.setErrorEnabled(true);
            textInputLayout.setError("Password between 6 and 20 alphanumeric characters");
            return false;
        } else if (!str.equals(str2)) {
            textInputLayout.setErrorEnabled(true);
            textInputLayout.setError("Password Not matching");
            return false;
        } else {
            textInputLayout.setError((CharSequence) null);
            return true;
        }
    }
}
