package com.example.easyexam.Adapter;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.example.easyexam.Activity.StartExamActivity;
import com.example.easyexam.Activity.SubjectWiseExamActivity;
import com.example.easyexam.Activity.SubjectWiseResultsActivity;
import com.example.easyexam.R;
import com.example.easyexam.Rest.Datum;
import com.example.easyexam.modelClass.Comman;

import java.util.List;


public class SubjectWiseResultAdapter extends RecyclerView.Adapter<SubjectWiseResultAdapter.ViewHolder> {

    List<Datum> newslist;
    Context contet;
    public Dialog dialog;

    public SubjectWiseResultAdapter(SubjectWiseResultsActivity newsActivity, List<Datum> items) {
        this.newslist = items;
        this.contet = newsActivity;
    }

    @Override
    public SubjectWiseResultAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemview = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_subject_wise_results, null);


        return new SubjectWiseResultAdapter.ViewHolder(itemview);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onBindViewHolder(final SubjectWiseResultAdapter.ViewHolder holder, final int position) {
        holder.txt_exam_date.setText("Date : " + Comman.isStrempty(newslist.get(position).getExamDate()));
        holder.txt_exam_name.setText("Exam name : " + Comman.isStrempty(newslist.get(position).getExamName()));
        holder.txt_total_marks.setText("Total Marks : " + Comman.isStrempty(newslist.get(position).getTotalMarks()));
//        holder.txt_status.setText("Status : " + newslist.get(position).getStatus());
        holder.txt_exam_marks_total.setText("Total correct Ans : " + Comman.isStrempty(newslist.get(position).getCorrectMarks()));
        holder.txt_start_time.setText("Exam time : " + Comman.isStrempty(newslist.get(position).getStartTime()) + " to " + Comman.isStrempty(newslist.get(position).getEndTime()));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(contet, StartExamActivity.class);
                intent.putExtra("EXAM_ID", newslist.get(position).getExamId());
                intent.putExtra("EXAM_NAME", newslist.get(position).getExamName());
                contet.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return newslist.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView txt_exam_date;
        TextView txt_start_time;
        TextView txt_exam_name;
        TextView txt_total_marks;
        TextView txt_status;
        TextView txt_exam_marks_total;


        public ViewHolder(View itemView) {
            super(itemView);
            txt_exam_date = (TextView) itemView.findViewById(R.id.txt_exam_date);
            txt_exam_name = (TextView) itemView.findViewById(R.id.txt_exam_name);
            txt_start_time = (TextView) itemView.findViewById(R.id.txt_start_time);
            txt_total_marks = (TextView) itemView.findViewById(R.id.txt_total_marks);
            txt_exam_marks_total = (TextView) itemView.findViewById(R.id.txt_exam_marks_total);
            txt_status = (TextView) itemView.findViewById(R.id.txt_status);

        }
    }
}
